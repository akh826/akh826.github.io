# Site Storage Inspector (Browser Extension)

Inspect **any website you have open in a tab** — localStorage, sessionStorage, Cache Storage, IndexedDB, and cookies (including **HttpOnly**).

A normal web page cannot read another site’s storage (same-origin policy). This extension runs only when **you** click it on the tab you want to inspect.

## Install (Chrome / Edge)

1. Open `chrome://extensions` (or `edge://extensions`).
2. Enable **Developer mode**.
3. Click **Load unpacked**.
4. Select this folder: `extension/storage-inspector-extension/`.

## Use

1. Navigate to the site you want to inspect (e.g. `https://example.com`).
2. Click the extension icon in the toolbar.
3. Click **Inspect active tab**.
4. Optional: **Open full report** for a larger view.

## Limits

- Cannot inspect `chrome://`, `edge://`, `about:`, or the Web Store.
- HTTP disk cache still cannot be listed (browser limitation).
- You must have permission to view the tab; private/incognito may require allowing the extension in incognito mode (extension settings).

## Pair with web tool

The page tool at `tools/storage-quota/` only reads **its own origin**. Use this extension for other sites.
